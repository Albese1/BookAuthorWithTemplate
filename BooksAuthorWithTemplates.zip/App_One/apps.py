from django.apps import AppConfig


class AppOneConfig(AppConfig):
    name = 'App_One'
